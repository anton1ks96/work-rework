package com.example.serviceresume.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "main"; // Spring автоматически найдет index.html в папке static
    }
}