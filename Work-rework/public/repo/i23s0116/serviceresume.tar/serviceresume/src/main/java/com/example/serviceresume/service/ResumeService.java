package com.example.serviceresume.service;

import com.example.serviceresume.model.Resume;
import com.example.serviceresume.repository.ResumeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ResumeService {
    @Autowired
    private ResumeRepository resumeRepository;

    public List<Resume> getAllResumes() {
        return resumeRepository.findAll();
    }

    public Resume saveResume(Resume resume) {
        return resumeRepository.save(resume);
    }

    public List<Resume> filterResumesByTcourse(String tcourse) {
        return resumeRepository.findByTcourseContaining(tcourse);
    }

    public List<Resume> filterResumesByProfile(String profile) {
        return resumeRepository.findByProfileContaining(profile);
    }

    public List<Resume> filterResumesByLink(String link) {
        return resumeRepository.findByLinkContaining(link);
    }

    public Optional<Resume> findById(Long id) {
        return resumeRepository.findById(id);
    }

    public void deleteById(Long id) {
        resumeRepository.deleteById(id);
    }
}