package com.example.serviceresume.controller;

import com.example.serviceresume.model.Resume;
import com.example.serviceresume.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/resumes")
public class ResumeController {
    @Autowired
    private ResumeService resumeService;

    @GetMapping("/get all")
    public ResponseEntity<List<Resume>> getAllResumes() {
        return ResponseEntity.ok(resumeService.getAllResumes());
    }

    @PostMapping("/add")
    public Resume createResume(@RequestBody Resume resume) {
        return resumeService.saveResume(resume);
    }

    @PutMapping("/save")
    public ResponseEntity<Resume> editResume(@RequestBody Resume resume) {
        Optional<Resume> oResume = resumeService.findById(resume.getId());
        if (oResume.isPresent())
            return ResponseEntity.ok(resumeService.saveResume(resume));
        else
            return ResponseEntity.notFound().build();
    }


    @GetMapping("/filter/tcourse")
    public List<Resume> filterByTcourse(@RequestParam String tcourse) {
        return resumeService.filterResumesByTcourse(tcourse);
    }

    @GetMapping("/filter/profile")
    public List<Resume> filterByProfile(@RequestParam String profile) {
        return resumeService.filterResumesByProfile(profile);
    }

    @GetMapping("/filter/link")
    public List<Resume> filterByLink(@RequestParam String link) {
        return resumeService.filterResumesByLink(link);
    }

    @GetMapping("/{id}")
    public  ResponseEntity<Resume> findById(@PathVariable Long id){
        Optional<Resume> oResume = resumeService.findById(id);
        if (oResume.isPresent())
            return ResponseEntity.ok(oResume.get());
        else
            return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public  ResponseEntity<Resume> deleteById(@PathVariable Long id){
        Optional<Resume> oResume = resumeService.findById(id);
        if (oResume.isPresent()) {
            resumeService.deleteById(id);
            return ResponseEntity.ok().build();
        }
        else
            return ResponseEntity.notFound().build();
    }
}