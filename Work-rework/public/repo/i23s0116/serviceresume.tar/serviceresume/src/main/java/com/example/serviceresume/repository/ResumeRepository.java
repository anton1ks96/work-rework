package com.example.serviceresume.repository;

import com.example.serviceresume.model.Resume;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ResumeRepository extends JpaRepository<Resume, Long> {
    List<Resume> findByTcourseContaining(String tcourse);
    List<Resume> findByProfileContaining(String profile);
    List<Resume> findByLinkContaining(String link);
}