package com.example.serviceresume;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceresumeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceresumeApplication.class, args);
	}

}
