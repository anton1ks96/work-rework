document.addEventListener('DOMContentLoaded', () => {
    const studentsList = document.getElementById('students-list');
    const filterCourse = document.getElementById('filter-course');
    const filterSpecialty = document.getElementById('filter-specialty');
    const filterDirection = document.getElementById('filter-direction'); 
    let students = JSON.parse(localStorage.getItem('students')) || [];

    const modal = document.getElementById('edit-modal');
    const editName = document.getElementById('edit-name');
    const editCourse = document.getElementById('edit-course');
    const editSpecialty = document.getElementById('edit-specialty');
    const editBio = document.getElementById('edit-bio');
    const saveEdit = document.getElementById('save-edit');
    const cancelEdit = document.getElementById('cancel-edit');

    let currentIndex = null;

    const openModal = (student, index) => {
        editName.value = student.name;
        editCourse.value = student.course;
        editSpecialty.value = student.specialty;
        editBio.value = student.bio || ''; 
        currentIndex = index;
        modal.style.display = 'block';
    };

    const closeModalWindow = () => {
        modal.style.display = 'none';
        currentIndex = null;
    };

    saveEdit.addEventListener('click', () => {
        if (currentIndex !== null) {
            const updatedStudent = {
                name: editName.value,
                course: editCourse.value,
                specialty: editSpecialty.value,
                bio: editBio.value,
            };
            students[currentIndex] = updatedStudent;
            localStorage.setItem('students', JSON.stringify(students));
            applyFilters(); 
            closeModalWindow();
        }
    });

    cancelEdit.addEventListener('click', closeModalWindow);

    const renderStudents = (filteredStudents) => {
        if (filteredStudents.length === 0) {
            studentsList.innerHTML = '<p>Студенты не найдены</p>';
            return;
        }

        studentsList.innerHTML = filteredStudents.map((student, index) => `
            <div class="student-card">
                <h3>${student.name}</h3>
                <p><strong>Курс:</strong> ${student.course}</p>
                <p><strong>Специальность:</strong> ${student.specialty}</p>
                <p><strong>О себе:</strong> ${student.bio || 'Не указано'}</p>
                <button class="edit" data-index="${index}">Редактировать</button>
                <button class="delete" data-index="${index}">Удалить</button>
            </div>
        `).join('');

        document.querySelectorAll('.edit').forEach(button => {
            button.addEventListener('click', (e) => {
                const index = e.target.dataset.index;
                openModal(students[index], index);
            });
        });

        document.querySelectorAll('.delete').forEach(button => {
            button.addEventListener('click', (e) => {
                const index = e.target.dataset.index;
                students.splice(index, 1);
                localStorage.setItem('students', JSON.stringify(students));
                applyFilters();  
            });
        });
    };

    const applyFilters = () => {
        const selectedCourse = filterCourse.value;
        const selectedSpecialty = filterSpecialty.value;
        const selectedDirection = filterDirection ? filterDirection.value : '';

        const filteredStudents = students.filter(student => {
            return (
                (selectedCourse === '' || student.course === selectedCourse) &&
                (selectedSpecialty === '' || student.specialty === selectedSpecialty) &&
                (selectedDirection === '' || student.direction === selectedDirection)
            );
        });

        renderStudents(filteredStudents);
    };

    filterCourse.addEventListener('change', applyFilters);
    filterSpecialty.addEventListener('change', applyFilters);
    if (filterDirection) {
        filterDirection.addEventListener('change', applyFilters);
    }

    renderStudents(students);
});