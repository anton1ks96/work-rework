document.addEventListener('DOMContentLoaded', () => {
    const studentsList = document.getElementById('students-list');
    const studentForm = document.getElementById('student-form');
    const apiBaseUrl = 'http://10.3.18.53:8081/api/resumes'; // URL API бэкенда

    const renderStudents = async () => {
        try {
            const response = await fetch(apiBaseUrl);
            if (!response.ok) {
                throw new Error('Ошибка при загрузке данных');
            }

            const students = await response.json();
            if (students.length === 0) {
                studentsList.innerHTML = '<p>Список студентов пуст</p>';
                return;
            }

            studentsList.innerHTML = students.map((student) => `
                <div class="student-card">
                    <h3>${student.name}</h3>
                    <p><strong>Курс:</strong> ${student.tcourse}</p>
                    <p><strong>Специальность:</strong> ${student.profile}</p>
                    <p><strong>Ссылка:</strong> ${student.link || 'Информация отсутствует'}</p>
                    <button class="edit" data-id="${student.id}">Редактировать</button>
                    <button class="delete" data-id="${student.id}">Удалить</button>
                </div>
            `).join('');

            document.querySelectorAll('.delete').forEach(button => {
                button.addEventListener('click', async (e) => {
                    const id = e.target.dataset.id;
                    await deleteStudent(id);
                    renderStudents();
                });
            });

            document.querySelectorAll('.edit').forEach(button => {
                button.addEventListener('click', (e) => {
                    const id = e.target.dataset.id;
                    openEditModal(id);
                });
            });
        } catch (error) {
            console.error(error);
            studentsList.innerHTML = '<p>Ошибка при загрузке данных</p>';
        }
    };

    const addStudent = async (student) => {
        try {
            const response = await fetch(apiBaseUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(student)
            });

            if (!response.ok) {
                throw new Error('Ошибка при добавлении студента');
            }
        } catch (error) {
            console.error(error);
        }
    };

    const deleteStudent = async (id) => {
        try {
            const response = await fetch(`${apiBaseUrl}/${id}`, { method: 'DELETE' });
            if (!response.ok) {
                throw new Error('Ошибка при удалении студента');
            }
        } catch (error) {
            console.error(error);
        }
    };

    studentForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const name = document.getElementById('student-name').value;
        const course = document.getElementById('student-course').value;
        const specialty = document.getElementById('student-specialty').value;
        const link = document.getElementById('student-link').value;

        const newStudent = { name, tcourse: course, profile: specialty, link };
        await addStudent(newStudent);

        renderStudents();
    });

    renderStudents();
});

