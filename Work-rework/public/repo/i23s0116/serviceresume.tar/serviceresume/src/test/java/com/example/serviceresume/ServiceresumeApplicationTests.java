package com.example.serviceresume;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceresumeApplicationTests {

	@Test
	void contextLoads() {
	}

}
